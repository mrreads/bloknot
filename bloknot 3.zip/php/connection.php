<?php
    $host = 'localhost';
    $database = 'bloknot';
    $user = 'root';
    $password = '';

    $link = mysqli_connect($host, $user, $password, $database);